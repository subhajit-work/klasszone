import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoadingController, AlertController, ToastController, MenuController } from '@ionic/angular';

import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { Observable, from } from 'rxjs';
import { take } from 'rxjs/operators';

import { AuthService } from '../../services/auth/auth.service';
import { CommonUtils } from '../../services/common-utils/common-utils';
import{ AppComponent } from'../../app.component';


/* tslint:disable */ 
@Component({
  selector: 'app-auth',
  templateUrl: './auth.page.html',
  styleUrls: ['./auth.page.scss']
})
export class AuthPage implements OnInit {

  isLoading = false;
  userInfoLoading: any;

  isLogin = true;
  userTypes: any;
  model:any = {}

  constructor( 
    private authService:AuthService,
    private router:Router,
    private loadingController: LoadingController,
    private alertCtrl: AlertController,
    public menuCtrl: MenuController,
    private commonUtils: CommonUtils,
    private http : HttpClient,
    private storage: Storage,
    private appComponent: AppComponent,
  ) { }

  ngOnInit() {
    // menu hide
    this.menuCtrl.enable(false);

    this.authService.globalparamsData.subscribe(res => {
      console.log('auth res >>>>>>>>', res);
      if(res && res != null && res != undefined && res != ''){
        // if(res.token != undefined ){
        //   this.router.navigateByUrl('/dashboard');
        // }
      }
    });
  }

  ionViewWillEnter() {

    // this.appComponent.userInfoData();

    // menu hide
    this.menuCtrl.enable(false);

    this.authService.globalparamsData.subscribe(res => {
      if(res && res != null && res != undefined && res != ''){
        // if(res.token != undefined ){
        //   this.router.navigateByUrl('/dashboard');
        // }
      }
    });
  }


  onSwitchAuthMode(){
    this.isLogin =! this.isLogin;
  }

  //---------------- login form submit start-----------------
    onSubmitForm(form:NgForm){
      this.isLoading = true;
      // console.log('form >>', form);
      if(!form.valid){
        return;
      }
      const email = form.value.email;
      const password = form.value.password;

      if(this.isLogin){
        // login server data send
      }else{
        // signup server data send
      }

      console.log('form.value', form.value);
      

      this.authenticate('login_register.php?action=login', form, form.value);
      // form.reset();

    }

    // authenticate function
    authenticate(_serverApi: string, _form: NgForm, form_data: any) {
      console.log('_serverApi >>>>>>>>>',_serverApi);
      console.log('_form >>>>>>>>>',_form);
      this.isLoading = true;
      this.loadingController
        .create({ 
          keyboardClose: true, 
          message: 'Logging in...',
          spinner: "bubbles",
          cssClass: 'custom-loading',
        })
        .then(loadingEl => {
          loadingEl.present();
          let authObs: Observable<any>;

          if (this.isLogin) {
            authObs = this.authService.login(_serverApi, form_data, '');
            authObs.subscribe(
              resData => {
                console.log('resData', resData);
                if(resData.return_status == 2){
                  this.router.navigateByUrl(`verification-email/${resData.return_data.user_id}`);
                  console.log('verification-email', resData.return_data.user_id);
                  this.commonUtils.presentToast('success', resData.return_message);
                  loadingEl.dismiss();
  
                }else if(resData.return_status > 0){
                  console.log('resData.return_status > 0', resData.return_status);
                  this.router.navigateByUrl('/dashboard');
  
                  this.appComponent.userInfoData();
                  console.log('user Type =============))))))))))))))>', resData.return_data.user_type);
                  
                  loadingEl.dismiss();
                  
                  
                }else{
                  loadingEl.dismiss();
                  this.commonUtils.presentToast('error', resData.return_message[0]);
                }
                
                this.isLoading = false;
              },
              errRes => {
                loadingEl.dismiss();
              }
            );
          } else {
            // authObs = this.authService.signup(email, password);
          }
          
          
        });
    }
  // login form submit end

private showAlert(message: string) {
  this.alertCtrl
    .create({
      header: 'Authentication failed',
      message: message,
      buttons: ['Okay']
    })
    .then(alertEl => alertEl.present());
}


}
