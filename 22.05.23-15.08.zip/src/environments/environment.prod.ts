export const environment = {
  production: true,
  apiUrl:'https://www.innovintent.com/mobile_app_api', 
  fileUrl:'https://www.innovintent.com/images'
};
