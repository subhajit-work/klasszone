export const environment = {
  production: true,
  apiMaster:'1',
  apiUrl:'https://klasszone.indinews24.com/Api', 
  fileUrl:'https://klasszone.indinews24.com/Api'
};
